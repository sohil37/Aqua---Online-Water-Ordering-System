package com.example.waterorder2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ContactUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);

        final EditText namecontactus = (EditText) (findViewById(R.id.namecontactus));
        final EditText phonecontactus = (EditText) (findViewById(R.id.phonecontactus));
        final EditText emailcontactus = (EditText) (findViewById(R.id.emailcontactus));
        final EditText messagecontactus = (EditText) (findViewById(R.id.messagecontactus));
        Button btn = (Button) findViewById(R.id.sendcontactus);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("message/html");
                emailIntent.putExtra(Intent.EXTRA_EMAIL,new String[]{"sohil.gurung@vit.edu.in"});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "My Query");
                emailIntent.putExtra(Intent.EXTRA_TEXT,
                        "Name: " + namecontactus.getText() +
                                "\n \n Contact Nunber: " + phonecontactus.getText() +
                                "\n \n Email address: " + emailcontactus.getText() +
                                "\n \n Message: " + messagecontactus.getText());
                try {
                    startActivity(Intent.createChooser(emailIntent,"Please select email"));
                }
                catch (android.content.ActivityNotFoundException ex)
                {
                    Toast.makeText(ContactUs.this, "There are no Email Clients", Toast.LENGTH_SHORT).show();
                }

            }
        });

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        findViewById(R.id.dashboardcontactus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ContactUs.this, Dashboard.class);
                startActivity(intent);
            }
        });
    }

    public void locationcontactus(View View)
    {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/Vidyalankar+Institute+of+Technology/@19.0216029,72.8686177,17z/data=!3m1!4b1!4m5!3m4!1s0x3be7cf39360e550b:0x119d357f39d6fdb7!8m2!3d19.0215978!4d72.8708064"));
        startActivity(browserIntent);
    }

    public void callcontactus(View View)
    {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:02222372237"));
        startActivity(intent);
    }

    public void gmailcontactus(View View)
    {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("message/html");
        emailIntent.putExtra(Intent.EXTRA_EMAIL,new String[]{"sohil.gurung@vit.edu.in"});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "");
        try {
            startActivity(Intent.createChooser(emailIntent,"Please select email"));
        }
        catch (android.content.ActivityNotFoundException ex)
        {
            Toast.makeText(ContactUs.this, "There are no Email Clients", Toast.LENGTH_SHORT).show();
        }
    }
}
