package com.example.waterorder2;

import androidx.fragment.app.FragmentActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;

public class CrisisMap extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private static final LatLng JOGESHWARI = new LatLng(19.148237, 72.850067);
    private static final LatLng VILE_PARLE = new LatLng(19.106088, 72.844615);
    private static final LatLng JVPD = new LatLng(19.106829, 72.824156);
    private static final LatLng LOKHANDWALA = new LatLng(19.138906, 72.806643);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crisis_map);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        Polygon polygon1 = googleMap.addPolygon(new PolygonOptions()
                .clickable(true)
                .add(
                        new LatLng(19.148237, 72.850067),
                        new LatLng(19.106088, 72.844615),
                        new LatLng(19.106829, 72.824156),
                        new LatLng(19.138906, 72.806643))
                .fillColor(Color.argb(30, 100, 0, 255))
                .strokeColor(Color.RED)
                .strokeWidth(10)
        );
        polygon1.setTag("alpha");
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(JOGESHWARI,13));
    }
}
