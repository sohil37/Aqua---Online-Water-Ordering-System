package com.example.waterorder2;

import com.example.waterorder2.Remote.IGoogleAPIService;
import com.example.waterorder2.Remote.RetrofitClient;

public class Common {

    private static final String GOOGLE_API_url = "https://maps.googleapis.com/";

    public static IGoogleAPIService getGoogleAPIService()
    {
        return RetrofitClient.getClient(GOOGLE_API_url).create(IGoogleAPIService.class);
    }
}
