package com.example.waterorder2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Feedback extends AppCompatActivity {

    EditText name, phone, email, feedback;
    Button sendfeedback;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        findViewById(R.id.dashboardfeedback).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Feedback.this, Dashboard.class);
                startActivity(intent);
            }
        });

        name = (EditText) findViewById(R.id.name);
        phone = (EditText) findViewById(R.id.phone);
        email = (EditText) findViewById(R.id.email);
        feedback = (EditText) findViewById(R.id.feedback);

        sendfeedback = (Button) findViewById(R.id.sendfeedback);
        databaseReference = FirebaseDatabase.getInstance().getReference();

        sendfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uname = name.getText().toString();
                String uphone = phone.getText().toString();
                String uemail = email.getText().toString();
                String ufeedback = feedback.getText().toString();

                User user = new User(uname, uphone, uemail, ufeedback);
                databaseReference.child("Save").child(uname).setValue(user);
                Toast.makeText(Feedback.this, "Thankyou for Sharing your feedback", Toast.LENGTH_SHORT).show();
            }
        });

    }
}



