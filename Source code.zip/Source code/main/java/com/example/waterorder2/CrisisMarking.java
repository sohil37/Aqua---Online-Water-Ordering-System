package com.example.waterorder2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

public class CrisisMarking extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crisis_marking);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        findViewById(R.id.dashboardcrisis).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CrisisMarking.this, Dashboard.class);
                startActivity(intent);
            }
        });

        ImageView img = (ImageView) findViewById(R.id.imageView2);

        img.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent act2 = new Intent(CrisisMarking.this, CrisisMap.class);
                startActivity(act2);
            }
        });
    }
}
