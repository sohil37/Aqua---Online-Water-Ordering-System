package com.example.waterorder2.activities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;
import com.example.waterorder2.R;

public class AmbikaOrderNowActivity extends AppCompatActivity {

    private static final int REQUEST_LOCATION=1;

    LocationManager locationManager;
    String latitude, longitude;

    Random rand = new Random();
    int upperbound = 1000;
    int int_random = rand.nextInt(upperbound);
    Button finalizeBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ambika_order_now);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        ActivityCompat.requestPermissions(this, new String[]
                {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);


        final EditText name = (EditText) (findViewById(R.id.editTextTextPersonName));
        final EditText email = (EditText) (findViewById(R.id.editTextTextEmailAddress));
        final EditText phone = (EditText) (findViewById(R.id.editTextPhone));
        final EditText address = (EditText) (findViewById(R.id.editTextTextPostalAddress));
        final EditText quantity1 = (EditText) (findViewById(R.id.editTextNumber));
        final EditText quantity2 = (EditText) (findViewById(R.id.editTextNumber1));
        final EditText quantity3 = (EditText) (findViewById(R.id.editTextNumber2));
        final EditText quantity4 = (EditText) (findViewById(R.id.editTextNumber3));
        final TextView totalPrice = (TextView) (findViewById(R.id.totalPrice));

        if(quantity1.getText().toString().length() == 0){
            quantity1.setText("0");
        }
        if(quantity2.getText().toString().length() == 0){
            quantity2.setText("0");
        }
        if(quantity3.getText().toString().length() == 0){
            quantity3.setText("0");
        }
        if(quantity4.getText().toString().length() == 0){
            quantity4.setText("0");
        }


        finalizeBtn = (Button) findViewById(R.id.finalizeBtn);

        finalizeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                locationManager=(LocationManager) getSystemService(Context.LOCATION_SERVICE);

                if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                    OnGPS();
                }
                else{
                    getLocation();
                }

                if(quantity1.getText().toString().length() == 0){
                    quantity1.setText("0");
                }
                if(quantity2.getText().toString().length() == 0){
                    quantity2.setText("0");
                }
                if(quantity3.getText().toString().length() == 0){
                    quantity3.setText("0");
                }
                if(quantity4.getText().toString().length() == 0){
                    quantity4.setText("0");
                }
                int price1 = Integer.parseInt(quantity1.getText().toString());
                int quantity1Total = price1 * 2500;
                int price2 = Integer.parseInt(quantity2.getText().toString());
                int quantity2Total = price2 * 750;
                int price3 = Integer.parseInt(quantity3.getText().toString());
                int quantity3Total = price3 * 1250;
                int price4 = Integer.parseInt(quantity4.getText().toString());
                int quantity4Total = price4 * 500;
                int total = quantity1Total + quantity2Total + quantity3Total + quantity4Total;

                totalPrice.setText(String.valueOf(total));
            }
        });



        Button btn = (Button) findViewById(R.id.placeOrder);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("message/html");
                emailIntent.putExtra(Intent.EXTRA_EMAIL,new String[]{"ordernow@ambikasuppliers.com"});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "New Order From " + name.getText());
                emailIntent.putExtra(Intent.EXTRA_TEXT,
                        "Name: " + name.getText() +
                                "\n \n Contact Number: " + phone.getText() +
                                "\n \n Email address: " + email.getText() +
                                "\n \n Address: " + address.getText() +
                                "\n \n 5 Tons BMC Water Tanker: Rs. 2,500: " + quantity1.getText() +
                                "\n \n 1 Ton BMC Water Tanker: Rs. 750: " + quantity2.getText() +
                                "\n \n 5 Tons Borewell Water Tanker: Rs. 1,250: " + quantity3.getText() +
                                "\n \n 1 Ton Borewell Water Tanker: Rs. 500: " + quantity4.getText() +
                                "\n \n Total: " + totalPrice.getText() +
                                "\n \n Location Co-ordinates: " + latitude + "," + longitude +
                                "\n \n Order Id: " + int_random);
                try {
                    startActivity(Intent.createChooser(emailIntent,"Please select email"));
                }
                catch (android.content.ActivityNotFoundException ex)
                {
                    Toast.makeText(AmbikaOrderNowActivity.this, "There are no Email Clients", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void OnGPS(){
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        final AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }

    private void getLocation(){
        if(ActivityCompat.checkSelfPermission(AmbikaOrderNowActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(AmbikaOrderNowActivity.this,
                Manifest.permission.ACCESS_COARSE_LOCATION) !=PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        }
        else{
            Location LocationGps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location LocationNetwork=locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location LocationPassive=locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);

            if(LocationGps != null)
            {
                double lat=LocationGps.getLatitude();
                double longi=LocationGps.getLongitude();

                latitude=String.valueOf(lat);
                longitude=String.valueOf(longi);

            }
            else if(LocationNetwork != null)
            {
                double lat=LocationNetwork.getLatitude();
                double longi=LocationNetwork.getLongitude();

                latitude=String.valueOf(lat);
                longitude=String.valueOf(longi);

            }
            else if(LocationPassive != null)
            {
                double lat=LocationPassive.getLatitude();
                double longi=LocationPassive.getLongitude();

                latitude=String.valueOf(lat);
                longitude=String.valueOf(longi);

            }
            else{
                Toast.makeText(this, "Can't Get Your Location", Toast.LENGTH_SHORT).show();
            }
        }
    }
}