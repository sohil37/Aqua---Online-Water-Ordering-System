package com.example.waterorder2.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import com.example.waterorder2.Dashboard;
import com.example.waterorder2.R;

public class SwastikOrderComplaintActivity extends AppCompatActivity {

    Button button, button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_swastik_order_complaint);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        findViewById(R.id.dashboardswastik).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(SwastikOrderComplaintActivity.this, Dashboard.class);
                startActivity(intent);
            }
        });

        button = (Button)findViewById(R.id.swastikOrderNowBtn);
        button1 = (Button)findViewById(R.id.swastikComplainBtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), SwastikOrderNowActivity.class);
                startActivity(i);
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), SwastikComplaintActivity.class);
                startActivity(i);
            }
        });
    }
}