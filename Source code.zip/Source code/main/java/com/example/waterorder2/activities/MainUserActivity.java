package com.example.waterorder2.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import com.example.waterorder2.Dashboard;
import com.example.waterorder2.R;

public class MainUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_user);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        findViewById(R.id.ambikaBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainUserActivity.this, AmbikaOderComplaintActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.omBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainUserActivity.this, OmOrderComplaintActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.swarupBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainUserActivity.this, SwarupOrderComplaintActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.swastikBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainUserActivity.this, SwastikOrderComplaintActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.dashboardmainuser).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainUserActivity.this, Dashboard.class);
                startActivity(intent);
            }
        });
    }
}