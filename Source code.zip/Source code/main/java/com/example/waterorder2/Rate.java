package com.example.waterorder2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.app.ProgressDialog;
import androidx.annotation.NonNull;
import com.example.waterorder2.activities.LoginActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.util.HashMap;

public class Rate extends AppCompatActivity {

    TextView resultrate;
    Button btnfeedback;
    ImageView charPlace;
    RatingBar rateStars;
    String answerValue;
    Animation charanim, btt;

    private Uri image_uri;

    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);

        firebaseAuth = FirebaseAuth.getInstance();
        checkUser();
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait");
        progressDialog.setCanceledOnTouchOutside(false);

        btnfeedback = (Button) findViewById(R.id.btnfeedback);

        btnfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = String.valueOf(rateStars.getRating());
                Toast.makeText(getApplicationContext(), s + "Stars", Toast.LENGTH_SHORT).show();

                if(v==btnfeedback){
                    updateProfile();
                }
            }
        });

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        findViewById(R.id.dashboardrate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Rate.this, Dashboard.class);
                startActivity(intent);
            }
        });

        resultrate = findViewById(R.id.resultrate);

        btnfeedback = findViewById(R.id.btnfeedback);

        charPlace = findViewById(R.id.charPlace);

        rateStars = findViewById(R.id.rateStars);

        charanim = AnimationUtils.loadAnimation(this, R.anim.charanim);
        btt = AnimationUtils.loadAnimation(this, R.anim.btt);

        charPlace.startAnimation(charanim);
        btnfeedback.startAnimation(btt);

        rateStars.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                answerValue = String.valueOf((int) (rateStars.getRating()));

                if(answerValue.equals("1")) {
                    charPlace.setImageResource(R.drawable.onestar);
                    charPlace.startAnimation(charanim);
                    btnfeedback.startAnimation(btt);
                    resultrate.setText("Just So So");
                }
                else if(answerValue.equals("2")) {
                    charPlace.setImageResource(R.drawable.onestar);
                    charPlace.startAnimation(charanim);
                    btnfeedback.startAnimation(btt);
                    resultrate.setText("Just So So");
                }
                else if(answerValue.equals("3")) {
                    charPlace.setImageResource(R.drawable.threestar);
                    charPlace.startAnimation(charanim);
                    btnfeedback.startAnimation(btt);
                    resultrate.setText("Good Job");
                }
                else if(answerValue.equals("4")) {
                    charPlace.setImageResource(R.drawable.fivestar);
                    charPlace.startAnimation(charanim);
                    btnfeedback.startAnimation(btt);
                    resultrate.setText("Good Job");
                }
                else if(answerValue.equals("5")) {
                    charPlace.setImageResource(R.drawable.fivestar);
                    charPlace.startAnimation(charanim);
                    btnfeedback.startAnimation(btt);
                    resultrate.setText("Awesome");
                }
                else {
                    Toast.makeText(getApplicationContext(), "No Point", Toast.LENGTH_SHORT).show();
                }

            }
        });

        Typeface mr = Typeface.createFromAsset(getAssets(), "font/mr.ttf");
        Typeface mm = Typeface.createFromAsset(getAssets(), "font/mm.ttf");

        resultrate.setTypeface(mm);
        btnfeedback.setTypeface(mm);

    }

    private void updateProfile() {
        progressDialog.setMessage("Thankyou for rating us");
        progressDialog.show();

        if (image_uri == null) {
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("rating", "" + answerValue);

            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
            ref.child(firebaseAuth.getUid()).updateChildren(hashMap)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            progressDialog.dismiss();
                            Toast.makeText(Rate.this, "Thankyou for rating us", Toast.LENGTH_SHORT).show();

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(Rate.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            String filePathAndName = "profile_images/" + "" + firebaseAuth.getUid();
            StorageReference storageReference = FirebaseStorage.getInstance().getReference(filePathAndName);
            storageReference.putFile(image_uri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                            while (!uriTask.isSuccessful()) ;
                            Uri downlaodImageUri = uriTask.getResult();

                            if (uriTask.isSuccessful()) {
                                HashMap<String, Object> hashMap = new HashMap<>();
                                hashMap.put("rating", "" + answerValue);

                                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
                                ref.child(firebaseAuth.getUid()).updateChildren(hashMap)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                progressDialog.dismiss();
                                                Toast.makeText(Rate.this, "Thankyou for rating us", Toast.LENGTH_SHORT).show();

                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                progressDialog.dismiss();
                                                Toast.makeText(Rate.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        });
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(Rate.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private void checkUser() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user == null) {
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
            finish();
        } else {
            loadMyInfo();
        }
    }

    private void loadMyInfo() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("uid").equalTo(firebaseAuth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
    }
}
