package com.example.waterorder2.Remote;

import com.example.waterorder2.models.Myplaces;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

public interface IGoogleAPIService {
    @GET
    Call<Myplaces> getNearbyPlaces(@Url String url);
}
